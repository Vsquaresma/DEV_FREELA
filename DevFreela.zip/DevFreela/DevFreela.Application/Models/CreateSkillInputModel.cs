﻿namespace DevFreela.Application.Models
{
    public class CreateSkillInputModel
    {
        public string Description { get; set; }
    }
}
